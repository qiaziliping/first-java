package cn.enjoyedu.rw;

/**
 *@author Mark老师   享学课堂 https://enjoy.ke.qq.com 
 *
 *更多课程咨询 依娜老师  QQ：2133576719  VIP课程咨询 依娜老师  QQ：2133576719
 *
 *类说明：商品的服务的接口
 */
public interface GoodsService {

	public GoodsInfo getNum();//获得商品的信息
	public void setNum(int number);//设置商品的数量
}
