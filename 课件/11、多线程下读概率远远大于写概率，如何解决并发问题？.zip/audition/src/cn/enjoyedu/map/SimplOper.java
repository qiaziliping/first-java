package cn.enjoyedu.map;

/**
 *@author Mark老师   享学课堂 https://enjoy.ke.qq.com 
 *
 *更多课程咨询 依娜老师  QQ：2133576719  VIP课程咨询 依娜老师  QQ：2133576719
 *
 *类说明：简单的程序会有线程安全问题吗？
 */
public class SimplOper {

    private long count =0;//累加计数器

	//count进行累加
    public synchronized void incCount(){
        count++;
    }

    //线程
    private static class Count extends Thread{

        private SimplOper simplOper;

        public Count(SimplOper simplOper) {
            this.simplOper = simplOper;
        }

        @Override
        public void run() {
            for(int i=0;i<10000;i++){
                simplOper.incCount();//加10000
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        SimplOper simplOper = new SimplOper();
        //启动两个线程
        Count count1 = new Count(simplOper);
        Count count2 = new Count(simplOper);
        count1.start();
        count2.start();
        Thread.sleep(50);
        System.out.println(simplOper.count);//=20000
    }

}
