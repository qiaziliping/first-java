package cn.enjoy.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {

	public String index() {
		return "springboot 2.0  我正在加载UserService";
	}

}
