package cn.enjoy.utls;

import org.springframework.context.annotation.Configuration;

/**
 * Created by VULCAN on 2018/9/28.
 */



public class MyBean {

    public void method() {
        System.out.println("MyBean.method()");
    }
}
