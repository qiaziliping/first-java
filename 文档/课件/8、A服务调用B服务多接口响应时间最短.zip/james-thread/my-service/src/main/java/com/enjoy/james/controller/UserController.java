package com.enjoy.james.controller;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.async.DeferredResult;

import com.enjoy.james.service.UserService;
import com.enjoy.james.service.UserServiceThread;
import com.enjoy.james.service.UserServiceThreadDeferred;

/**
 * 控制层：对外开放接口地址及路径 http://127.0.0.1:8080/my-service/main/user?userId=123
 * 
 * @author 【享学课堂】 James老师QQ：1076258117 架构技术QQ群：684504192
 * @throws Exception
 */
@Controller
@RequestMapping("/main")
public class UserController {

	@Autowired
	private UserService userService;

	// 对外提供的接口
	@RequestMapping(value = "/user")
	@ResponseBody
	public String getUserInfo(String userId) {
		return userService.getUserInfo(userId).toString();
	}

	// 接口聚合：并行

	@Autowired
	private UserServiceThread userServiceThread;

	@RequestMapping(value = "/userThread")
	@ResponseBody
	public String getUserThreadInfo(String userId) throws InterruptedException, ExecutionException {

		return userServiceThread.getUserInfo(userId).toString();
	}

	
	
	
	
	
	
	
	@RequestMapping(value = "/userThreadAsync")
	@ResponseBody
	public Callable<String> userThreadAsync(String userId) {
		// tomcat主线程
		System.out.println("主线程开始…………" + Thread.currentThread() + "==>" + System.currentTimeMillis());

		Callable<String> callable = new Callable<String>() {
			@Override
			public String call() throws Exception {
				System.out.println("副线程开始。…………" + Thread.currentThread() + "==>" + System.currentTimeMillis());
				String result = userServiceThread.getUserInfo(userId).toString();
				System.out.println("副线程结束。…………" + Thread.currentThread() + "==>" + System.currentTimeMillis());
				return result;
			}
		};
		System.out.println("主线程结束…………" + Thread.currentThread() + "==>" + System.currentTimeMillis());
		return callable;
	}

	
	
	
	
	
	
	
	
	
	
	@Autowired
	UserServiceThreadDeferred userServiceThreadDeferred;
	protected static ExecutorService taskExecutor = Executors.newFixedThreadPool(10);

	// 用户登录
	@RequestMapping(value = "/testDeff")
	@ResponseBody
	public DeferredResult<String> login(String userId) {
		System.out.println("主线程开始..." + Thread.currentThread() + "==>" + System.currentTimeMillis());

		DeferredResult<String> deferredResult = new DeferredResult<String>(20000L, "----------failed----------");

		taskExecutor.submit(new Runnable() {
			@Override
			public void run() {
				System.out.println("副线程开始..." + Thread.currentThread() + "==>" + System.currentTimeMillis());
				try {
					userServiceThreadDeferred.getUserInfoDefer(userId, deferredResult);
				} catch (InterruptedException e) {
					e.printStackTrace();
				} catch (ExecutionException e) {
					e.printStackTrace();
				}
				System.out.println("副线程开始..." + Thread.currentThread() + "==>" + System.currentTimeMillis());
			}
		});
		System.out.println("主线程结束..." + Thread.currentThread() + "==>" + System.currentTimeMillis());
		return deferredResult;
	}
}
