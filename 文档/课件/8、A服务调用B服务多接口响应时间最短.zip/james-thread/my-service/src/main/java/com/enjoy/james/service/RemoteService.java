/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2014-2016 abel533@gmail.com
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package com.enjoy.james.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


/**
 * @author James
 * @since 2018-08-31 21:42
 */
@Service
public class RemoteService {
	@Autowired
	private RestTemplate restTemplate;
	
	//获取用户基本信息
	public String getUserInfo(String userId) {

    	long currentTimeMillis = System.currentTimeMillis();
		String result = restTemplate.getForEntity("http://127.0.0.1:9080/user/getUserInfo?userId="+userId, String.class).getBody();

    	System.out.println("获取用户基本信息时间为"+(System.currentTimeMillis()-currentTimeMillis));
		return result;
	}

	//获取用户余额
	public String getUserMoney(String userId) {

    	long currentTimeMillis = System.currentTimeMillis();
		String result = restTemplate.getForEntity("http://127.0.0.1:9080/money/getMoneyInfo?userId="+userId, String.class).getBody();

    	System.out.println("获取用户余额时间为"+(System.currentTimeMillis()-currentTimeMillis));
		return result;
	}
}
