/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2014-2016 abel533@gmail.com
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package com.enjoy.james.service;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.async.DeferredResult;

import com.alibaba.fastjson.JSONObject;


/**串行
 * @author James
 * @since 2018-08-31 21:42
 */
@Service
public class UserServiceThreadDeferred {

	@Autowired
	RemoteService remoteService;
	
	@Autowired
    protected static ExecutorService taskExecutor = Executors.newFixedThreadPool(10);
	
	
	//待实现 调用 用户系统   积分系统  余额系统…………。
    public void getUserInfoDefer(String userId,DeferredResult<String> deferredResult) throws InterruptedException, ExecutionException{
    	long currentTimeMillis = System.currentTimeMillis();
    	
    	 
    	//获取用户信息接口封装
    	Callable<JSONObject> queryUserInfo = new Callable<JSONObject>() {
    		@Override
			public JSONObject call() throws Exception {
    			//调用远程的方法
				String v1 = remoteService.getUserInfo(userId);
		    	JSONObject userInfo = JSONObject.parseObject(v1);
				return userInfo; //有返回值
			}
		};
    	
		//获取用户的余额接口
    	Callable<JSONObject> queryMoneyInfo = new Callable<JSONObject>() {
    		@Override
			public JSONObject call() throws Exception {
    			//获取用户的余额接口
    	    	String v2 = remoteService.getUserMoney(userId);
    	    	JSONObject moneyInfo = JSONObject.parseObject(v2);
				return moneyInfo; //有返回值
			}
		};
    	
    	FutureTask<JSONObject> queryUserInfoTask = new FutureTask<JSONObject>(queryUserInfo);
    	FutureTask<JSONObject> queryMoneyInfoTask = new FutureTask<JSONObject>(queryMoneyInfo);
		
		//获取用户信息
		new Thread(queryUserInfoTask).start();
		new Thread(queryMoneyInfoTask).start();
		
		taskExecutor.submit(queryUserInfoTask);
		taskExecutor.submit(queryMoneyInfoTask);
		
		JSONObject result = new JSONObject();
		
		//拿到callable的返回值
		//阻塞：没有拿Futuretask执行结果前，后面的代码是不执行
		result.putAll(queryUserInfoTask.get());
		result.putAll(queryMoneyInfoTask.get());
		
		System.out.println("执行总时间为"+(System.currentTimeMillis()-currentTimeMillis));
    	deferredResult.setResult(result.toString());
    	
    }
    
  
}

