package com.enjoy.james.task;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class JamesFutureTask<V> implements Runnable,Future<V>{

	Callable<V> callable ;  //封装业务逻辑
	
	V result = null ; //执行结果
	
	public JamesFutureTask(Callable<V> callable){
		this.callable = callable;
	}

	
	//多线程执行run
	@Override
	public void run() {
		try {
			result = callable.call();
		} catch (Exception e) {
			e.printStackTrace();
		}
		//锁new JamesFutureTask的实例   notifyAll()和wait（）必须放锁synchronized里，不放锁里不能用
		synchronized(this){
			System.out.println("-----");
			this.notifyAll();  //通知所有在 this实例等待的线程，将其唤醒（其实就是this.wait();）
		}
	}

	@Override
	public V get() throws InterruptedException, ExecutionException {
		if(result != null){
			return result;
		}
		System.out.println("等待执行结果……等待中");
		synchronized (this) {
			this.wait();  //等待futurtask执行完，全部线程…………。
		}
		return result;
	}
	
	
	
	
	@Override
	public boolean cancel(boolean mayInterruptIfRunning) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCancelled() {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public boolean isDone() {
		// TODO Auto-generated method stub
		return false;
	}

	

	@Override
	public V get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
		// TODO Auto-generated method stub
		return null;
	}
}
